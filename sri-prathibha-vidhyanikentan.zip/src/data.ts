import { Achievement, Facility, GalleryItem } from "./types";

export const SCHOOL_STATS = [
  { value: "20+", label: "Years of Academic Trust", description: "Educating minds since 2006" },
  { value: "IIT-F", label: "IIT Foundation Classes", description: "Specialized coaching starting this year for interested students" },
  { value: "100%", label: "Interactive Smart Classrooms", description: "Equipped with high-end digital boards" },
  { value: "5000+", label: "Successful Alumni", description: "Empowered professional global citizens" },
];

export const SCHOOL_FACILITIES: Facility[] = [
  {
    id: "fac-1",
    name: "Interactive Digital Classrooms",
    description: "Every classroom in Sri Prathibha Vidhyanikentan features premium interactive digital smart boards, moving away from chalkdust to high-resolution visual layouts, 3D simulations, and engaging collaborative teaching models.",
    featureTitle: "Smart Classroom Standards",
    features: [
      "High-Resolution Interactive Digital Boards",
      "Dynamic visual syllabus mappings",
      "Audio-visual multimedia lectures",
      "Digital student response systems"
    ],
    specs: ["Scribe-touch multi-input technology", "Curated visual content repositories", "Dust-free healthy ambient spaces"]
  },
  {
    id: "fac-2",
    name: "Advanced Science & Computer labs",
    description: "Our state-of-the-art laboratories allow students to convert abstract textbook theory into tangible, practical observations. We host fully separation-safe Physics, Chemistry, Biology, and computer workspace labs.",
    featureTitle: "Lab Equipment & Infrastructure",
    features: [
      "Modern experimental models and microscopes",
      "Individual workspace slots & apparatus sets",
      "Supervised chemical reagent systems",
      "High-speed Intel network computing lab"
    ],
    specs: ["Meets all safety clearance standards", "Fully furnished computer laboratory terminal", "Qualified expert laboratory curators"]
  },
  {
    id: "fac-3",
    name: "Expansive Multi-Sport Playground",
    description: "We strongly believe that a healthy mind resides in a healthy body. Sri Prathibha Vidhyanikentan boasts an incredibly sprawling, fully leveled open playground, allowing students to train, play, and excel in regional tournaments.",
    featureTitle: "Playground & Sports Academy",
    features: [
      "Interactive sports play arenas",
      "Lined Volleyball Court & Kabaddi Grid",
      "Full-length athletic sprint trails",
      "Equipped Cricket nets & accessory kits"
    ],
    specs: ["2-Acres of secure campus play space", "Full-time expert physical training instructors", "Custom structured intra-school sports calendar"]
  }
];

export const ACADEMIC_ACHIEVEMENTS: Achievement[] = [
  {
    id: "ach-1",
    title: "100% Pass Board Track Record",
    metric: "100% Pass Rate",
    description: "Achieved an absolute 100% pass percentage milestone in the board examinations, demonstrating top-tier school preparation.",
    category: "Academic",
    year: "2025"
  },
  {
    id: "ach-2",
    title: "Best Results in Sports",
    metric: "SGF All-Round Championship",
    description: "Outstanding accomplishments across state and district tournaments, confirming our sports-first focus on high-scale playgrounds.",
    category: "Sports",
    year: "2025"
  },
  {
    id: "ach-3",
    title: "District Athletics & Kabaddi Cup",
    metric: "Champions",
    description: "Our school Kabaddi team secured 1st place in the Mahabubnagar District School Games Federation.",
    category: "Sports",
    year: "2025"
  },
  {
    id: "ach-4",
    title: "Telangana Folk & Fine Arts Festival",
    metric: "First Prize Winners",
    description: "Winner of the traditional state-level cultural performance for depicting classical regional history.",
    category: "Extracurricular",
    year: "2024"
  },
  {
    id: "ach-5",
    title: "Scribblers Debating & Public Speaking",
    metric: "Best School Delegation",
    description: "Students successfully contested regional public forums, securing major awards in the junior debate league.",
    category: "Extracurricular",
    year: "2025"
  },
  {
    id: "ach-6",
    title: "Dedicated Computer Labs for Students",
    metric: "1:1 System Ratio",
    description: "Successfully commissioned a modern tech computing suite, ensuring individual workspace terminal slots for every single student.",
    category: "Academic",
    year: "2026"
  }
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: "gal-1",
    title: "Smart Digital Classrooms",
    category: "Campus",
    description: "Students actively participating in a live coordinate geometry session on interactive smart-boards.",
    imageAlt: "Children in front of interactive smartboard",
    iconName: "Monitor"
  },
  {
    id: "gal-2",
    title: "Chemistry Laboratory Explorers",
    category: "Labs",
    description: "High school scholars performing acid-base titration experiments with safe personal workspace apparatus under guidance.",
    imageAlt: "Students using multi-flask chemistry laboratory kits with test tubes",
    iconName: "Beaker"
  },
  {
    id: "gal-3",
    title: "District Kabaddi Field Triumph",
    category: "Sports",
    description: "Sri Prathibha Vidhyanikentan Kabaddi squad raising the championship trophy on our vast playground.",
    imageAlt: "Championship team celebrating on open green playground",
    iconName: "Trophy"
  },
  {
    id: "gal-4",
    title: "The Tech & ICT Laboratory",
    category: "Labs",
    description: "Young programming heads developing interactive visual modules using block-coding in the desktop lab.",
    imageAlt: "Bright computer lab workspace with high resolution desktop computers",
    iconName: "Cpu"
  },
  {
    id: "gal-5",
    title: "Annual Day Cultural Extravaganza",
    category: "Celebrations",
    description: "Students presenting energetic Telangana traditional dance forms on our state-of-the-art stage.",
    imageAlt: "Colorful student music and folk play performance with vibrant costuming",
    iconName: "Sparkles"
  },
  {
    id: "gal-6",
    title: "Inter-School Science & Craft Exhibition",
    category: "Celebrations",
    description: "Dynamic showcase of smart city models and working robotic prototypes designed entirely by students.",
    imageAlt: "Display desk with model clean energy city and student inventor presenting",
    iconName: "Lightbulb"
  }
];

export const ADMISSION_GRADES = [
  "Nursery / Playgroup",
  "LKG / UKG",
  "Grade 1 to 5 (Primary School)",
  "Grade 6 to 8 (Middle School)",
  "Grade 9 & 10 (Secondary SSC)"
];

export const ADMISSION_FAQ = [
  {
    q: "What curriculum does Sri Prathibha Vidhyanikentan follow?",
    a: "We offer a state-of-the-art curriculum mapping both the Telangana State SSC milestones and foundational CBSE concepts to ensure competitive readiness."
  },
  {
    q: "What is the contact number and address of the school administrative desk?",
    a: "Our administrative hotline is +91 9133054131. You can visit our pristine campus in Rajapur Mandal, Mahabubnagar District, Telangana."
  },
  {
    q: "Why are interactive digital boards important?",
    a: "They replace traditional blackboards, offering rich imagery, instant educational video playbacks, and dynamic game-based learning models to sustain child engagement."
  },
  {
    q: "What documents are required during primary admissions?",
    a: "A copy of the child's birth certificate, original transfer certificate (TC) from the previous school, latest academic progress reports, and 4 passport size photos."
  }
];
