import React, { useState, useEffect, useRef } from "react";
import { 
  motion, 
  AnimatePresence 
} from "motion/react";
import { 
  Phone, 
  MapPin, 
  Clock, 
  GraduationCap, 
  Trophy, 
  BookOpen, 
  MessageSquare, 
  Sparkles, 
  Check, 
  ChevronRight, 
  ShieldCheck, 
  X, 
  Send, 
  SendHorizontal, 
  HelpCircle, 
  FileText, 
  Search, 
  Tv, 
  Dribbble, 
  FlaskConical, 
  Menu, 
  ArrowUpRight,
  User,
  Heart,
  ListTodo,
  Lock,
  CheckSquare,
  CheckCircle,
  XCircle
} from "lucide-react";

import { 
  SCHOOL_STATS, 
  SCHOOL_FACILITIES, 
  ACADEMIC_ACHIEVEMENTS, 
  GALLERY_ITEMS, 
  ADMISSION_GRADES, 
  ADMISSION_FAQ 
} from "./data";
import { Admission, Message } from "./types";

export default function App() {
  // Navigation & tabs
  const [activeTab, setActiveTab] = useState<"home" | "achievements" | "facilities" | "gallery" | "admission">("home");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Gallery filter
  const [galleryFilter, setGalleryFilter] = useState<"All" | "Campus" | "Labs" | "Sports" | "Celebrations">("All");
  
  // Achievement filter
  const [achievementFilter, setAchievementFilter] = useState<"All" | "Academic" | "Sports" | "Extracurricular">("All");

  // Admissions state
  const [admissionForm, setAdmissionForm] = useState({
    studentName: "",
    parentName: "",
    grade: "Nursery / Playgroup",
    phone: "",
    email: "",
    previousSchool: "",
    notes: ""
  });
  const [submissionStatus, setSubmissionStatus] = useState<"idle" | "submitting" | "success" | "error">("idle");
  const [submittedAdmission, setSubmittedAdmission] = useState<Admission | null>(null);
  const [trackingPhone, setTrackingPhone] = useState("");
  const [trackedApplications, setTrackedApplications] = useState<Admission[]>([]);
  const [trackingChecked, setTrackingChecked] = useState(false);

  // AI Tutor / Assistant Chat state
  const [aiChatOpen, setAiChatOpen] = useState(false);
  const [aiMessages, setAiMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Namaste! 🙏 Welcome to Sri Prathibha Vidhyanikentan School. I am your AI Admission Coach and Student Tutor. I'm here to help you learn about our 20+ year legacy, our digital classrooms, science labs, the playground, and guide you with the admission process. Ask me anything!",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [userMsgInput, setUserMsgInput] = useState("");
  const [isAiTyping, setIsAiTyping] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Dynamic state for counting current total registrations live
  const [admissionsCount, setAdmissionsCount] = useState<number>(2);
  const [dispatchedSmsList, setDispatchedSmsList] = useState<any[]>([]);

  // Admin confirmation states
  const [isAdminUnlocked, setIsAdminUnlocked] = useState(false);
  const [adminPinInput, setAdminPinInput] = useState("");
  const [adminModeError, setAdminModeError] = useState("");
  const [allAdmissionsList, setAllAdmissionsList] = useState<Admission[]>([]);
  const [adminActionStatus, setAdminActionStatus] = useState<{ id: string; status: "idle" | "submitting" | "success" | "error"; error?: string }>({ id: "", status: "idle" });
  const [adminSubTab, setAdminSubTab] = useState<"pending" | "confirmed" | "declined">("pending");

  const fetchAdmissionsData = async () => {
    try {
      // Fetch admission list
      const response = await fetch("/api/admission/list");
      const resData = await response.json();
      if (response.ok && resData.success) {
        setAdmissionsCount(resData.count || resData.data?.length || 0);
      }

      // Fetch dispatched SMS outbox logs
      const smsResponse = await fetch("/api/admission/dispatched-sms");
      const smsData = await smsResponse.json();
      if (smsResponse.ok && smsData.success) {
        setDispatchedSmsList(smsData.data || []);
      }
    } catch (err) {
      console.error("Error fetching admissions quantity / sms", err);
    }
  };

  // Load registered applications initially to show trace (if any)
  useEffect(() => {
    fetchAdmissionsData();
    // Refresh list on a gentle schedule
    const interval = setInterval(fetchAdmissionsData, 10000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    // Scroll chat bottom
    if (chatBottomRef.current) {
      chatBottomRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [aiMessages, aiChatOpen]);

  // Handle Admission Form submit
  const handleAdmissionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!admissionForm.studentName || !admissionForm.parentName || !admissionForm.phone) {
      alert("Please fill in the required fields: Student Name, Parent Name, and Contact Number.");
      return;
    }
    setSubmissionStatus("submitting");

    try {
      const response = await fetch("/api/admission/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(admissionForm)
      });
      const data = await response.json();
      if (response.ok && data.success) {
        setSubmissionStatus("success");
        setSubmittedAdmission(data.data);
        fetchAdmissionsData(); // Instantly update navigation badge counter and dispatch outbox!
        // Reset form
        setAdmissionForm({
          studentName: "",
          parentName: "",
          grade: "Nursery / Playgroup",
          phone: "",
          email: "",
          previousSchool: "",
          notes: ""
        });
        // Auto add a greeting from AI Tutor explaining next steps
        triggerAiTutorMessage(`Hi, I just submitted an admission application for my child ${data.data.studentName} for class ${data.data.grade}. What are the next steps?`);
      } else {
        setSubmissionStatus("error");
      }
    } catch (err) {
      console.error(err);
      setSubmissionStatus("error");
    }
  };

  // Track admission by phone number
  const handleTrackAdmission = async () => {
    if (!trackingPhone) return;
    try {
      const response = await fetch("/api/admission/list");
      const resData = await response.json();
      if (response.ok && resData.success) {
        // Find matching entries by phone
        const query = trackingPhone.trim();
        const matches = resData.data.filter((adm: Admission) => 
          adm.phone.includes(query) || adm.id.toLowerCase() === query.toLowerCase()
        );
        setTrackedApplications(matches);
        setTrackingChecked(true);
      }
    } catch (err) {
      console.error("Tracking Error", err);
    }
  };

  const fetchAllAdmissionsForAdmin = async () => {
    try {
      const response = await fetch("/api/admission/list");
      const resData = await response.json();
      if (response.ok && resData.success) {
        setAllAdmissionsList(resData.data || []);
      }
    } catch (err) {
      console.error("Failed to load admissions for admin session", err);
    }
  };

  const handleAdminAuthentication = () => {
    const pin = adminPinInput.trim();
    if (pin === "Prathibha@2027" || pin === "7670968526") {
      setIsAdminUnlocked(true);
      setAdminModeError("");
      fetchAllAdmissionsForAdmin();
    } else {
      setAdminModeError("Access Denied: Invalid Administrative PIN or Password.");
    }
  };

  const handleConfirmAdmission = async (admissionId: string) => {
    const pin = adminPinInput.trim() || "Prathibha@2027"; // Fallback PIN
    setAdminActionStatus({ id: admissionId, status: "submitting" });
    try {
      const response = await fetch("/api/admission/confirm", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: admissionId, password: pin })
      });
      const data = await response.json();
      if (response.ok && data.success) {
        setAdminActionStatus({ id: admissionId, status: "success" });
        // Update both counts and individual records list
        fetchAdmissionsData();
        fetchAllAdmissionsForAdmin();
        
        // If we are currently tracking, update the tracked applications list in-place
        setTrackedApplications((prevTracked) => 
          prevTracked.map((adm) => 
            adm.id === admissionId ? { ...adm, status: "Confirmed" } : adm
          )
        );

        setTimeout(() => {
          setAdminActionStatus({ id: "", status: "idle" });
        }, 4000);
      } else {
        setAdminActionStatus({ id: admissionId, status: "error", error: data.error || "Verification failed." });
      }
    } catch (err: any) {
      setAdminActionStatus({ id: admissionId, status: "error", error: err.message || "Network error" });
    }
  };

  const handleDeclineAdmission = async (admissionId: string) => {
    const pin = adminPinInput.trim() || "Prathibha@2027"; // Fallback PIN
    setAdminActionStatus({ id: admissionId, status: "submitting" });
    try {
      const response = await fetch("/api/admission/decline", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: admissionId, password: pin })
      });
      const data = await response.json();
      if (response.ok && data.success) {
        setAdminActionStatus({ id: admissionId, status: "success" });
        // Update both counts and individual records list
        fetchAdmissionsData();
        fetchAllAdmissionsForAdmin();
        
        // If we are currently tracking, update the tracked applications list in-place
        setTrackedApplications((prevTracked) => 
          prevTracked.map((adm) => 
            adm.id === admissionId ? { ...adm, status: "Declined" } : adm
          )
        );

        setTimeout(() => {
          setAdminActionStatus({ id: "", status: "idle" });
        }, 4000);
      } else {
        setAdminActionStatus({ id: admissionId, status: "error", error: data.error || "Decline action failed." });
      }
    } catch (err: any) {
      setAdminActionStatus({ id: admissionId, status: "error", error: err.message || "Network error" });
    }
  };

  // Trigger automated AI message query from helpful click cards
  const triggerAiQuery = (queryText: string) => {
    setAiChatOpen(true);
    sendMessageToBackend(queryText);
  };

  // Handle message send to AI Tutor
  const handleSendAiMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userMsgInput.trim()) return;
    sendMessageToBackend(userMsgInput);
    setUserMsgInput("");
  };

  const triggerAiTutorMessage = (promptText: string) => {
    sendMessageToBackend(promptText);
  };

  const sendMessageToBackend = async (text: string) => {
    // Add user message to stack
    const newMsg: Message = {
      role: "user",
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    
    const updatedMessages = [...aiMessages, newMsg];
    setAiMessages(updatedMessages);
    setIsAiTyping(true);

    try {
      // Map message framework format to API expectations
      const apiMessages = updatedMessages.map(m => ({
        role: m.role,
        content: m.content
      }));

      const res = await fetch("/api/admission/ai-tutor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: apiMessages })
      });
      
      const data = await res.json();
      const botReply = data.text || "I was unable to process that. Please contact our administrative desk at +91 9133054131 directly!";
      
      setAiMessages(prev => [
        ...prev,
        {
          role: "assistant",
          content: botReply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } catch (err) {
      console.error("AI chat error", err);
      setAiMessages(prev => [
        ...prev,
        {
          role: "assistant",
          content: "Oops! We encountered a brief connection drop. Please double-check your credentials/API key, or reach our Admissions Officer at 9133054131! I'm still happy to help.",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setIsAiTyping(false);
    }
  };

  // Filter lists
  const filteredAchievements = ACADEMIC_ACHIEVEMENTS.filter((item) => {
    if (achievementFilter === "All") return true;
    return item.category === achievementFilter;
  });

  const filteredGallery = GALLERY_ITEMS.filter((item) => {
    if (galleryFilter === "All") return true;
    return item.category === galleryFilter;
  });

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans flex flex-col selection:bg-rose-500 selection:text-white">
      
      {/* Dynamic Header Notification Ribbon */}
      <div className="bg-gradient-to-r from-rose-600 via-indigo-600 to-amber-500 text-white py-2 px-4 text-xs font-semibold tracking-wider text-center flex flex-wrap justify-center gap-x-6 gap-y-1">
        <span className="flex items-center gap-1.5 justify-center">
          <Sparkles className="w-3.5 h-3.5 animate-pulse text-amber-300" />
          Admissions Open for Year 2026-27!
        </span>
        <span className="flex items-center gap-1.5 justify-center">
          <Phone className="w-3.5 h-3.5" />
          Hotline: <a href="tel:9133054131" className="underline hover:text-rose-100 transition-colors">9133054131</a>
        </span>
        <span className="flex items-center gap-1.5 justify-center">
          <MapPin className="w-3.5 h-3.5" />
          Rajapur Mandal, Mahabubnagar District
        </span>
      </div>

      {/* Primary Navigation Hub */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-100 shadow-sm transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          
          {/* Logo Brand Brand */}
          <div 
            onClick={() => setActiveTab("home")} 
            className="flex items-center gap-3 cursor-pointer group"
            id="nav-logo"
          >
            <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-indigo-600 to-rose-600 flex items-center justify-center text-white font-extrabold shadow-md shadow-indigo-200 group-hover:scale-105 transition-transform">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xl font-bold font-display tracking-tight text-slate-900 block group-hover:text-indigo-600 transition-colors">
                Sri Prathibha Vidhyanikentan
              </span>
              <span className="text-[10px] uppercase font-bold tracking-widest text-slate-400 block -mt-1">
                20+ Years Academy • Rajapur
              </span>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            {[
              { id: "home", label: "Home" },
              { id: "achievements", label: "Achievements & Milestones" },
              { id: "facilities", label: "World-Class Facilities" },
              { id: "gallery", label: "Campus Life" },
              { id: "admission", label: "Admissions 2026" },
            ].map((tab) => (
              <button
                key={tab.id}
                id={`nav-${tab.id}`}
                onClick={() => {
                  setActiveTab(tab.id as any);
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
                className={`px-4 py-2 rounded-lg font-semibold text-sm transition-all duration-200 ${
                  activeTab === tab.id
                    ? "bg-indigo-50 text-indigo-700 shadow-sm"
                    : "text-slate-600 hover:text-indigo-600 hover:bg-slate-50"
                }`}
              >
                {tab.label}
              </button>
            ))}

            {/* Simulated live admissions count block */}
            <div 
              onClick={() => {
                setActiveTab("admission");
                window.scrollTo({ top: 1200, behavior: "smooth" });
              }}
              className="flex items-center gap-2 px-3 py-1.5 ml-2 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 hover:text-rose-800 rounded-full text-xs font-black shadow-sm transition-all cursor-pointer animate-pulse"
              id="navbar-live-admissions-desk"
              title="Click to view admissions list and real-time dispatches."
            >
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-600"></span>
              </span>
              <span>New Admissions: {admissionsCount}</span>
            </div>
          </nav>

          {/* Action Call for Admission */}
          <div className="hidden lg:flex items-center gap-4">
            <button
              onClick={() => {
                setActiveTab("admission");
                window.scrollTo({ top: 0, behavior: "smooth" });
              }}
              id="header-cta-admission"
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm px-5 py-2.5 rounded-xl transition-all shadow-md shadow-indigo-100 flex items-center gap-2 hover:translate-y-[-1px]"
            >
              Apply Online
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Mobile responsive toggle */}
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)} 
            className="md:hidden p-2 rounded-lg hover:bg-slate-100 transition-colors"
            id="mobile-menu-btn"
          >
            <Menu className="w-6 h-6 text-slate-700" />
          </button>
        </div>

        {/* Mobile Nav Dropdown */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-white border-t border-slate-100 px-4 py-4 space-y-2 block"
              id="mobile-nav-panel"
            >
              {[
                { id: "home", label: "Home Page" },
                { id: "achievements", label: "Academic Achievements" },
                { id: "facilities", label: "Campus Facilities" },
                { id: "gallery", label: "Milestones Gallery" },
                { id: "admission", label: "New Admissions Portal" },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => {
                    setActiveTab(tab.id as any);
                    setMobileMenuOpen(false);
                    window.scrollTo({ top: 0, behavior: "smooth" });
                  }}
                  className={`w-full text-left px-4 py-3 rounded-xl font-medium text-sm transition-colors block ${
                    activeTab === tab.id
                      ? "bg-indigo-50 text-indigo-700"
                      : "text-slate-600 hover:bg-slate-50"
                  }`}
                >
                  {tab.label}
                </button>
              ))}

              {/* Mobile live admissions count block */}
              <div 
                onClick={() => {
                  setActiveTab("admission");
                  setMobileMenuOpen(false);
                  window.scrollTo({ top: 1200, behavior: "smooth" });
                }}
                className="flex items-center justify-between p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 hover:bg-rose-100 cursor-pointer transition-colors"
                id="mobile-navbar-live-admissions"
              >
                <div className="flex items-center gap-2">
                  <span className="relative flex h-2.5 w-2.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-600"></span>
                  </span>
                  <span className="text-xs font-bold">New Admissions Registered</span>
                </div>
                <span className="bg-rose-600 text-white font-extrabold text-xs px-2 py-0.5 rounded-lg">
                  {admissionsCount} Total
                </span>
              </div>

              <div className="pt-3 border-t border-slate-100 mt-2">
                <button
                  onClick={() => {
                    setActiveTab("admission");
                    setMobileMenuOpen(false);
                    window.scrollTo({ top: 0, behavior: "smooth" });
                  }}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-center py-3 rounded-xl block text-sm animate-pulse"
                >
                  Apply Form Now
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Main Container Content */}
      <main className="flex-grow">
        
        {/* HOMEPAGE VIEW */}
        {activeTab === "home" && (
          <div>
            {/* HERO SECTION */}
            <section className="relative overflow-hidden bg-gradient-to-b from-indigo-50/50 via-white to-slate-50 pt-16 pb-20 lg:pt-24 lg:pb-32">
              <div className="absolute top-0 right-0 w-[400px] h-[400px] rounded-full bg-indigo-300/10 blur-3xl -z-10" />
              <div className="absolute bottom-0 left-0 w-[300px] h-[300px] rounded-full bg-rose-300/10 blur-3xl -z-10" />
              
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
                
                {/* Hero Words */}
                <div className="lg:col-span-7 space-y-8 text-center lg:text-left">
                  <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-100 text-xs font-bold uppercase tracking-wider justify-center lg:justify-start">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                    Celebrating 20+ Years of Academic Brilliance
                  </div>
                  
                  <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold font-display leading-[1.1] tracking-tight text-slate-900">
                    Nurturing Innovators, <br />
                    <span className="bg-gradient-to-r from-indigo-600 via-violet-600 to-rose-600 bg-clip-text text-transparent">
                      Empowering Leaders
                    </span>
                  </h1>
                  
                  <p className="text-lg text-slate-600 max-w-2xl mx-auto lg:mx-0 leading-relaxed font-sans">
                    Welcome to <strong className="text-slate-800">Sri Prathibha Vidhyanikentan</strong>, a premier temple of learning in Rajapur, Mahabubnagar. We blend our rich 20-year education legacy with cutting-edge <strong>digital smart boards</strong>, sophisticated science laboratories, and an elite sports curriculum.
                  </p>

                  <div className="flex flex-col sm:flex-row items-center gap-4 justify-center lg:justify-start">
                    <button
                      onClick={() => setActiveTab("admission")}
                      className="w-full sm:w-auto px-8 py-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-lg shadow-indigo-200 hover:shadow-xl transition-all flex items-center justify-center gap-2 text-sm hover:translate-y-[-1px]"
                      id="hero-apply-btn"
                    >
                      Admission Form 2026-27
                      <ChevronRight className="w-4 h-4" />
                    </button>
                    
                    <button
                      onClick={() => setAiChatOpen(true)}
                      className="w-full sm:w-auto px-8 py-4 bg-white hover:bg-slate-50 text-slate-700 font-bold rounded-xl border border-slate-200 transition-all flex items-center justify-center gap-2 text-sm hover:border-slate-300"
                      id="hero-chat-btn"
                    >
                      <MessageSquare className="w-4.5 h-4.5 text-indigo-600" />
                      Chat with AI Tutor
                    </button>
                  </div>

                  <div className="pt-4 grid grid-cols-3 gap-4 border-t border-slate-100 max-w-lg mx-auto lg:mx-0">
                    <div className="text-center lg:text-left">
                      <span className="block text-2xl font-bold font-display text-slate-900">20+ Yrs</span>
                      <span className="block text-xs font-semibold text-slate-500">Continuous Glory</span>
                    </div>
                    <div className="text-center lg:text-left border-l border-slate-200 pl-4">
                      <span className="block text-2xl font-bold font-display text-slate-900">100%</span>
                      <span className="block text-xs font-semibold text-slate-500">Digital Smart Boards</span>
                    </div>
                    <div className="text-center lg:text-left border-l border-slate-200 pl-4">
                      <span className="block text-2xl font-bold font-display text-slate-900">Modern</span>
                      <span className="block text-xs font-semibold text-slate-500">Science Labs</span>
                    </div>
                  </div>
                </div>

                {/* Hero Creative Bento Visual Mockup */}
                <div className="lg:col-span-5 relative">
                  <div className="bg-gradient-to-tr from-indigo-500 to-rose-500 rounded-3xl p-1.5 shadow-2xl relative">
                    <div className="bg-slate-900 rounded-[22px] overflow-hidden p-6 text-white space-y-6">
                      
                      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                        <div className="flex items-center gap-2">
                          <span className="w-3.5 h-3.5 rounded-full bg-rose-500 inline-block animate-ping" />
                          <span className="text-xs font-bold tracking-widest text-indigo-400 uppercase">Live Entrance Showcase</span>
                        </div>
                        <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">ESTD 2006</span>
                      </div>

                      <div className="space-y-4">
                        <h4 className="text-lg font-bold font-display leading-tight">
                          Our Blueprint for Tomorrow's Achievers
                        </h4>
                        
                        <div className="space-y-3">
                          <div className="flex items-start gap-3 bg-slate-800/50 p-3 rounded-lg border border-slate-800">
                            <div className="w-8 h-8 rounded-md bg-indigo-600/30 flex items-center justify-center text-indigo-400 flex-shrink-0">
                              <Tv className="w-4 h-4" />
                            </div>
                            <div>
                              <p className="text-xs font-bold">100% Smart Classrooms</p>
                              <p className="text-[10px] text-slate-400">Classrooms paired with modular digital screens for deep absorption</p>
                            </div>
                          </div>

                          <div className="flex items-start gap-3 bg-slate-800/50 p-3 rounded-lg border border-slate-800">
                            <div className="w-8 h-8 rounded-md bg-rose-600/30 flex items-center justify-center text-rose-400 flex-shrink-0">
                              <Dribbble className="w-4 h-4" />
                            </div>
                            <div>
                              <p className="text-xs font-bold">Professional Playgrounds</p>
                              <p className="text-[10px] text-slate-400">Generous sports field for Cricket, Athletics, and Traditional games</p>
                            </div>
                          </div>

                          <div className="flex items-start gap-3 bg-slate-800/50 p-3 rounded-lg border border-slate-800">
                            <div className="w-8 h-8 rounded-md bg-amber-600/30 flex items-center justify-center text-amber-400 flex-shrink-0">
                              <FlaskConical className="w-4 h-4" />
                            </div>
                            <div>
                              <p className="text-xs font-bold">State-of-the-Art Labs</p>
                              <p className="text-[10px] text-slate-400">Fully equipped separate Biology, Physics, & Computer bays</p>
                            </div>
                          </div>
                        </div>

                        {/* Interactive Coach mini feature */}
                        <div className="p-3 bg-gradient-to-r from-slate-800 to-indigo-950 rounded-lg border border-indigo-900/40 flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="w-6 h-6 rounded-full bg-indigo-600 flex items-center justify-center text-white text-[10px] font-bold">AI</div>
                            <div>
                              <span className="block text-[11px] font-bold">AI Admissions Coach</span>
                              <span className="block text-[9px] text-indigo-300">Fast tracking application helper</span>
                            </div>
                          </div>
                          <button 
                            onClick={() => setAiChatOpen(true)}
                            className="bg-indigo-600 hover:bg-indigo-500 text-white text-[10px] font-bold px-2.5 py-1 rounded transition-all"
                          >
                            Talk
                          </button>
                        </div>

                      </div>

                    </div>
                  </div>
                </div>

              </div>
            </section>

            {/* EXPERIENCE HIGHLIGHTS & STATS */}
            <section className="py-20 bg-slate-900 text-white relative">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                
                <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
                  <h3 className="text-xs font-bold text-rose-500 uppercase tracking-widest block">Institutional Legacy</h3>
                  <h2 className="text-3xl sm:text-4xl font-bold font-display">20+ Years of Dedication & Growth</h2>
                  <p className="text-slate-400 text-sm leading-relaxed">
                    Sri Prathibha Vidhyanikentan has spent two decades pioneering quality education standards at Rajapur, Mahabubnagar. We offer rigorous SSC instruction, exceptional core logic mentoring, and well-being cultivation.
                  </p>
                </div>

                {/* Stats Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                  {SCHOOL_STATS.map((stat, idx) => (
                    <div 
                      key={idx} 
                      className="bg-slate-800/40 border border-slate-800 p-6 rounded-2xl relative hover:border-slate-700 transition-colors"
                    >
                      <div className="absolute top-4 right-4 w-1.5 h-1.5 rounded-full bg-indigo-500" />
                      <div className="text-4xl sm:text-5xl font-extrabold font-display bg-gradient-to-r from-indigo-400 to-rose-400 bg-clip-text text-transparent mb-2">
                        {stat.value}
                      </div>
                      <h4 className="text-sm font-bold text-slate-100 mb-1">{stat.label}</h4>
                      <p className="text-xs text-slate-400">{stat.description}</p>
                    </div>
                  ))}
                </div>

                {/* Quick Info Box */}
                <div className="mt-16 bg-gradient-to-r from-indigo-950 via-indigo-900 to-indigo-950 p-8 rounded-2xl border border-indigo-800 grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
                  <div className="md:col-span-2 space-y-2">
                    <span className="text-[10px] uppercase tracking-widest text-indigo-400 font-bold block">Visit Our Campus Today</span>
                    <h3 className="text-xl font-bold font-display">Experience Sri Prathibha Vidhyanikentan first hand</h3>
                    <p className="text-xs text-indigo-200">
                      Walk around our laboratories, explore the library, test our high-definition digital interactive smart boards, and see our generous play campus at Rajapur Mandal, Mahabubnagar.
                    </p>
                  </div>
                  <div className="text-center md:text-right">
                    <button 
                      onClick={() => setActiveTab("admission")}
                      className="inline-flex bg-white hover:bg-slate-50 text-indigo-950 px-6 py-3 rounded-lg text-xs font-extrabold uppercase tracking-widest shadow-md hover:shadow-lg transition-all"
                    >
                      Direct Admissions 2026
                    </button>
                  </div>
                </div>

              </div>
            </section>

            {/* THREE CORE PILLARS SECTION */}
            <section className="py-20 bg-white">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                
                <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
                  <h3 className="text-xs font-bold text-indigo-600 uppercase tracking-widest">Our Specialties</h3>
                  <h2 className="text-3xl sm:text-4xl font-extrabold font-display text-slate-950">A Perfect Environment To Bloom</h2>
                  <p className="text-slate-600 text-sm leading-relaxed">
                    We believe modern school education should extend beyond memory logs. Hence, we maintain exceptional infrastructure resources right here in Mahabubnagar district.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  
                  {/* Digital class */}
                  <div className="bg-slate-50 rounded-2xl p-8 border border-slate-100 relative group hover:shadow-xl hover:shadow-indigo-50 transition-all duration-300">
                    <div className="w-12 h-12 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                      <Tv className="w-6 h-6" />
                    </div>
                    <h3 className="text-lg font-bold font-display text-slate-900 mb-3">Interactive Digital Boards</h3>
                    <p className="text-xs text-slate-600 leading-relaxed mb-4">
                      No more monotonous lecture dictations. Every room features large touchscreen visual layouts mapping deep animated 3D simulations, bringing science, geography, and standard math geometry alive to your child.
                    </p>
                    <button 
                      onClick={() => { setActiveTab("facilities"); }}
                      className="text-xs font-bold text-indigo-600 flex items-center gap-1 group-hover:gap-2 transition-all mt-auto"
                    >
                      Explore features <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Labs */}
                  <div className="bg-slate-50 rounded-2xl p-8 border border-slate-100 relative group hover:shadow-xl hover:shadow-indigo-50 transition-all duration-300">
                    <div className="w-12 h-12 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                      <FlaskConical className="w-6 h-6" />
                    </div>
                    <h3 className="text-lg font-bold font-display text-slate-900 mb-3">State-of-the-Art Labs</h3>
                    <p className="text-xs text-slate-600 leading-relaxed mb-4">
                      Our elite laboratories for Chemistry, Biology, Physics, and ICT Computer systems boast updated kits, safety measures, and high system counts to provide a genuine experiential platform to young scholars.
                    </p>
                    <button 
                      onClick={() => { setActiveTab("facilities"); }}
                      className="text-xs font-bold text-indigo-600 flex items-center gap-1 group-hover:gap-2 transition-all mt-auto"
                    >
                      Explore labs <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Sports */}
                  <div className="bg-slate-50 rounded-2xl p-8 border border-slate-100 relative group hover:shadow-xl hover:shadow-indigo-50 transition-all duration-300">
                    <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                      <Dribbble className="w-6 h-6" />
                    </div>
                    <h3 className="text-lg font-bold font-display text-slate-900 mb-3">Generous Outdoor Playground</h3>
                    <p className="text-xs text-slate-600 leading-relaxed mb-4">
                      A pristine, carefully-leveled extensive sports ground dedicated to volleyball matches, cricket nets, kabaddi grids, and broad tactical development to bring healthy spirit, state trophies, and fitness.
                    </p>
                    <button 
                      onClick={() => { setActiveTab("facilities"); }}
                      className="text-xs font-bold text-indigo-600 flex items-center gap-1 group-hover:gap-2 transition-all mt-auto"
                    >
                      Explore sports <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                </div>

              </div>
            </section>

            {/* BRIEF TESTIMONIAL OR FOUNDERS MESSAGE */}
            <section className="py-20 bg-slate-50 border-t border-b border-slate-100">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="bg-white p-8 sm:p-12 rounded-3xl border border-slate-100 shadow-xl shadow-slate-100 relative overflow-hidden">
                  <div className="absolute top-0 left-0 bg-indigo-600 text-white text-[10px] font-bold px-4 py-1 uppercase tracking-widest rounded-br-2xl">
                    Our Founders
                  </div>
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
                    <div className="lg:col-span-8 space-y-6">
                      <div>
                        <h3 className="text-2xl font-bold font-display text-slate-900">
                          Founders' Vision & Academic Guidance
                        </h3>
                        <p className="text-sm text-slate-600 leading-relaxed mt-2">
                          Sri Prathibha Vidhyanikentan is founded and navigated by seasoned education leaders who bring deep pedagogical insights directly to classrooms. We believe in bridging high technological excellence with focused human dedication.
                        </p>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
                        <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 flex items-start gap-3">
                          <div className="w-10 h-10 rounded-full bg-indigo-600 text-white font-extrabold flex items-center justify-center text-sm flex-shrink-0">
                            BS
                          </div>
                          <div>
                            <h4 className="font-bold text-slate-900 text-sm">B. Sathyanarayana</h4>
                            <p className="text-xs text-indigo-600 font-semibold mb-1">Founder & Director</p>
                            <p className="text-[11px] text-slate-500">20+ Years of teaching & administrative leadership and technology integration.</p>
                          </div>
                        </div>

                        <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 flex items-start gap-3">
                          <div className="w-10 h-10 rounded-full bg-rose-600 text-white font-extrabold flex items-center justify-center text-sm flex-shrink-0">
                            GB
                          </div>
                          <div>
                            <h4 className="font-bold text-slate-900 text-sm">G. Balraj</h4>
                            <p className="text-xs text-rose-600 font-semibold mb-1">Founder & Academic Dean</p>
                            <p className="text-[11px] text-slate-500">20+ Years of teaching legacy, specializing in student counseling, guidance, and academic leadership.</p>
                          </div>
                        </div>
                      </div>

                      <p className="text-[11px] text-slate-400 italic">
                        Sri Prathibha Vidhyanikentan School, Rajapur Mandal, Mahabubnagar District.
                      </p>
                    </div>
                    <div className="lg:col-span-4 bg-slate-50 p-6 rounded-2xl border border-slate-100">
                      <h4 className="text-sm font-bold text-slate-900 mb-3">Need Instant Guidance?</h4>
                      <p className="text-xs text-slate-500 mb-4">
                        Speak directly with our specialized AI tutor. Learn about fee discounts, age limits, and SSC Board schedules.
                      </p>
                      <button 
                        onClick={() => setAiChatOpen(true)}
                        className="w-full py-2.5 bg-indigo-600 hover:bg-slate-900 text-white font-semibold rounded-xl text-xs transition-colors"
                      >
                        Launch Tutor Chat
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </section>

          </div>
        )}

        {/* ACHIEVEMENTS & MILESTONES VIEW */}
        {activeTab === "achievements" && (
          <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto space-y-4 mb-12 animate-fade-in">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-50 text-rose-700 border border-rose-100 text-xs font-bold uppercase tracking-wider">
                <Trophy className="w-3.5 h-3.5 text-rose-600" />
                Flexing Our Proud Statistics
              </div>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-display text-slate-900">
                Academic Honors & Student Milestones
              </h1>
              <p className="text-sm text-slate-600 leading-relaxed">
                Sri Prathibha Vidhyanikentan has delivered consistent board triumphs, Olympiad ranks, sports championships, and cultural rewards in Mahabubnagar District. Learn about our students' proudest accomplishments below.
              </p>
            </div>

            {/* Filter Navigation */}
            <div className="flex flex-wrap justify-center gap-2 mb-10">
              {["All", "Academic", "Sports", "Extracurricular"].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setAchievementFilter(cat as any)}
                  className={`px-4 sm:px-6 py-2 rounded-full font-bold text-xs transition-all ${
                    achievementFilter === cat
                      ? "bg-indigo-600 text-white shadow-md shadow-indigo-100"
                      : "bg-white hover:bg-slate-100 text-slate-600 border border-slate-200"
                  }`}
                >
                  {cat === "All" ? "All Triumphs & Medals" : `${cat} Honors`}
                </button>
              ))}
            </div>

            {/* Achievements Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredAchievements.map((ach) => (
                <div 
                  key={ach.id} 
                  className="bg-white rounded-2xl border border-slate-100 shadow-md shadow-slate-100/50 p-6 flex flex-col justify-between relative overflow-hidden hover:scale-[1.01] transition-all group"
                >
                  <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-indigo-500/5 to-transparent rounded-bl-full pointer-events-none" />
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <span className={`text-[10px] font-bold uppercase px-2.5 py-1 rounded-full ${
                        ach.category === "Academic" 
                          ? "bg-indigo-50 text-indigo-700" 
                          : ach.category === "Sports" 
                          ? "bg-amber-50 text-amber-700" 
                          : "bg-rose-50 text-rose-700"
                      }`}>
                        {ach.category}
                      </span>
                      <span className="text-xs font-mono font-bold text-slate-400">{ach.year}</span>
                    </div>

                    <h3 className="text-lg font-bold font-display text-slate-950 group-hover:text-indigo-600 transition-colors mb-2">
                      {ach.title}
                    </h3>
                    
                    <div className="text-2xl font-extrabold text-indigo-600 font-display mb-3">
                      {ach.metric}
                    </div>

                    <p className="text-xs text-slate-500 leading-relaxed mb-6">
                      {ach.description}
                    </p>
                  </div>

                  <div className="pt-4 border-t border-slate-50 flex items-center justify-between">
                    <span className="text-[10px] uppercase font-bold tracking-widest text-slate-400">Authorized SSC Merit</span>
                    <button 
                      onClick={() => triggerAiQuery(`Tell me more details about your ${ach.title} performance`)}
                      className="text-xs font-bold text-indigo-600 hover:underline flex items-center gap-1"
                    >
                      Verify with AI <ArrowUpRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Call to action card */}
            <div className="mt-16 bg-slate-900 rounded-3xl p-8 sm:p-12 text-white relative overflow-hidden">
              <div className="absolute bottom-[-100px] right-[-100px] w-80 h-80 rounded-full bg-indigo-600/20 blur-3xl" />
              <div className="max-w-xl space-y-4 relative">
                <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">Enrolling for the New Batch</span>
                <h3 className="text-2xl sm:text-3xl font-bold font-display">Specialized IIT Foundation Core Classes</h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Introduced starting this academic year for interested high-performing students. Deep dive into analytical mathematics, physical mechanics, and advanced logic to pave a secure entry into elite technical institutes.
                </p>
                <div className="pt-2 flex flex-wrap gap-4">
                  <button 
                    onClick={() => setActiveTab("admission")}
                    className="bg-indigo-600 hover:bg-white hover:text-indigo-900 text-white font-bold text-xs px-6 py-3 rounded-xl transition-all"
                  >
                    Start Admission Form
                  </button>
                  <a 
                    href="tel:9133054131"
                    className="bg-white/10 hover:bg-white/20 border border-slate-700 text-white font-bold text-xs px-6 py-3 rounded-xl transition-all flex items-center gap-2 justify-center"
                  >
                    <Phone className="w-3.5 h-3.5 text-rose-400" />
                    Call Principal: 9133054131
                  </a>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* WORLD-CLASS FACILITIES VIEW */}
        {activeTab === "facilities" && (
          <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 text-indigo-700 border border-slate-200 text-xs font-bold uppercase tracking-wider">
                <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />
            Designed For Exceptional Outcomes
              </div>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-display text-slate-900">
                School Facilities & Learning Assets
              </h1>
              <p className="text-sm text-slate-600 leading-relaxed">
                Take a deeply descriptive visual review of Sri Prathibha Vidhyanikentan's prime assets. From interactive touchscreen panels to large security boundary playing grids.
              </p>
            </div>

            <div className="space-y-16">
              {SCHOOL_FACILITIES.map((facility, idx) => (
                <div 
                  key={facility.id} 
                  className={`grid grid-cols-1 lg:grid-cols-12 gap-12 items-center ${
                    idx % 2 === 1 ? "lg:flex-row-reverse" : ""
                  }`}
                >
                  
                  {/* Left Descriptive column */}
                  <div className={`lg:col-span-6 space-y-6 ${idx % 2 === 1 ? "lg:order-last" : ""}`}>
                    <span className="text-[10px] uppercase font-bold tracking-widest text-indigo-600 bg-indigo-50 border border-indigo-100 px-3 py-1 rounded-md">
                      Pillars of Excellence #0{idx + 1}
                    </span>
                    <h2 className="text-2xl sm:text-3xl font-bold font-display text-slate-900">
                      {facility.name}
                    </h2>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      {facility.description}
                    </p>

                    <div className="space-y-3 bg-white p-6 rounded-2xl border border-slate-100">
                      <h4 className="text-xs font-bold text-indigo-950 uppercase tracking-wider flex items-center gap-1">
                        <Check className="w-4 h-4 text-emerald-500" />
                        {facility.featureTitle}
                      </h4>
                      <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {facility.features.map((feat, fidx) => (
                          <li key={fidx} className="text-[11px] text-slate-500 flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 flex-shrink-0" />
                            {feat}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="space-y-1">
                      <span className="text-[10px] uppercase font-bold text-slate-400 block font-display">Technical Spec Highlights:</span>
                      <div className="flex flex-wrap gap-2">
                        {facility.specs.map((spec, sidx) => (
                          <span key={sidx} className="bg-slate-100 text-slate-700 text-[10px] px-3 py-1 rounded-md border border-slate-200 font-semibold">
                            {spec}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="pt-2">
                      <button 
                        onClick={() => triggerAiQuery(`Tell me more about your ${facility.name} details`)}
                        className="px-5 py-2.5 bg-slate-900 hover:bg-indigo-600 text-white font-bold rounded-xl text-xs transition-all flex items-center gap-2"
                      >
                        Ask Tutor About {facility.name.split(" ")[0]} 
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>

                  </div>

                  {/* Right Creative Illustration Block mapping facilities */}
                  <div className="lg:col-span-6">
                    <div className="bg-white rounded-3xl p-8 border border-slate-100 shadow-xl relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-40 h-40 bg-indigo-500/5 rounded-bl-full pointer-events-none" />
                      
                      <div className="flex items-center gap-3 border-b border-slate-100 pb-4 mb-6">
                        <div className="w-10 h-10 rounded-lg bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold text-sm">
                          {idx === 0 ? <Tv className="w-5 h-5" /> : idx === 1 ? <FlaskConical className="w-5 h-5" /> : <Dribbble className="w-5 h-5" />}
                        </div>
                        <div>
                          <span className="block text-xs font-bold text-slate-900 font-display">CAMPUS MAP DIRECTORY</span>
                          <span className="block text-[10px] text-slate-400">Sri Prathibha Vidhyanikentan Campus</span>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                          <span className="text-[10px] uppercase tracking-wider text-rose-600 font-bold block mb-1">State Trust Verified</span>
                          <p className="text-xs text-slate-600 leading-relaxed font-sans">
                            {idx === 0 
                              ? "Sri Prathibha Vidhyanikentan was the first to implement active digital smartboard modules in Rajapur region, elevating math integration benchmarks."
                              : idx === 1 
                              ? "Specially ventilated computer spaces mapped to individual desktops ensure student developers can interact with modern typing tutorials effortlessly."
                              : "Our spacious playground of over 2-acres supports multiple volleyball tournaments and athletic practice, completely secured inside a boundary wall."
                            }
                          </p>
                        </div>

                        {/* Interactive FAQ box inside facilities details */}
                        <div className="p-4 bg-indigo-50/50 rounded-xl border border-indigo-100 text-indigo-950 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                          <div>
                            <span className="text-xs font-bold block">Admissions Coordinator Contact</span>
                            <span className="text-[10px] text-indigo-600">Got questions about facilities? Ask directly.</span>
                          </div>
                          <span className="text-xs font-bold font-mono bg-white px-2 py-1 rounded shadow-sm border border-indigo-200">
                            9133054131
                          </span>
                        </div>
                      </div>

                    </div>
                  </div>

                </div>
              ))}
            </div>
          </section>
        )}

        {/* GALLERY VIEW */}
        {activeTab === "gallery" && (
          <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto space-y-4 mb-12">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-100 text-xs font-bold uppercase tracking-wider">
                <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                Vibrant Campus Milestones
              </div>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-display text-slate-900">
                Milestones & Life at Sri Prathibha
              </h1>
              <p className="text-sm text-slate-600 leading-relaxed">
                Take a visual stroll through Sri Prathibha Vidhyanikentan School. Discover our interactive digital classrooms, spacious playground facilities, core laboratories, and celebratory annual day sports achievements.
              </p>
            </div>

            {/* Gallery Category Filter buttons */}
            <div className="flex flex-wrap justify-center gap-2 mb-10">
              {["All", "Campus", "Labs", "Sports", "Celebrations"].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setGalleryFilter(cat as any)}
                  className={`px-4 sm:px-5 py-2 rounded-xl text-xs font-bold transition-all ${
                    galleryFilter === cat
                      ? "bg-indigo-600 text-white shadow-md"
                      : "bg-white hover:bg-slate-100 text-slate-600 border border-slate-200"
                  }`}
                >
                  {cat === "All" ? "Full Campus View" : `${cat}`}
                </button>
              ))}
            </div>

            {/* Gallery Items Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredGallery.map((item) => (
                <div 
                  key={item.id} 
                  className="bg-white rounded-2xl border border-slate-100 overflow-hidden shadow-md shadow-slate-100 group hover:shadow-xl transition-all duration-300"
                >
                  {/* Styled fallback illustration for images without API key storage to maintain beautiful aesthetics */}
                  <div className="h-56 bg-gradient-to-tr from-slate-900 via-indigo-950 to-indigo-900 relative flex flex-col justify-between p-6 overflow-hidden">
                    <div className="absolute top-[-50px] right-[-50px] w-40 h-40 rounded-full bg-white/5 blur-xl group-hover:scale-125 transition-transform duration-500" />
                    
                    <div className="flex justify-between items-start z-10">
                      <span className="text-[9px] uppercase tracking-widest font-extrabold bg-white/10 text-white px-2.5 py-1 rounded-md backdrop-blur-sm border border-white/20">
                        {item.category}
                      </span>
                      <div className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center text-white">
                        {item.iconName === "Monitor" && <Tv className="w-4 h-4" />}
                        {item.iconName === "Beaker" && <FlaskConical className="w-4 h-4" />}
                        {item.iconName === "Trophy" && <Trophy className="w-4 h-4" />}
                        {item.iconName === "Cpu" && <CpuWorkaroundIcon />}
                        {item.iconName === "Sparkles" && <Sparkles className="w-4 h-4" />}
                        {item.iconName === "Lightbulb" && <BookOpen className="w-4 h-4" />}
                      </div>
                    </div>

                    <div className="space-y-1.5 z-10">
                      <span className="text-[10px] font-bold text-indigo-400 block tracking-wider uppercase font-mono">Verified Campus Asset</span>
                      <h4 className="text-base font-bold font-display text-white group-hover:text-amber-300 transition-colors">
                        {item.title}
                      </h4>
                    </div>
                  </div>

                  <div className="p-5 space-y-3">
                    <p className="text-xs text-slate-600 leading-relaxed font-sans">
                      {item.description}
                    </p>
                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                      <span className="text-[10px] font-bold text-slate-400 font-display">Estd. 2006 (20+ Yrs)</span>
                      <button 
                        onClick={() => triggerAiQuery(`Tell me what makes the ${item.title} facility special`)}
                        className="text-[11px] font-extrabold text-indigo-600 hover:text-indigo-800 transition-colors flex items-center gap-1"
                      >
                        Ask AI Coach <ChevronRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>

                </div>
              ))}
            </div>

            {/* General Highlights Bento Card */}
            <div className="mt-16 bg-gradient-to-r from-teal-50 to-indigo-50 p-8 rounded-3xl border border-indigo-100/50 flex flex-col md:flex-row gap-8 items-center justify-between text-slate-900">
              <div className="space-y-2">
                <span className="text-xs font-bold text-rose-600 uppercase tracking-widest block font-mono">Direct Student Milestones</span>
                <h3 className="text-xl font-bold font-display">Interested in a live guided tour of our modern lab?</h3>
                <p className="text-xs text-slate-500 max-w-xl">
                  Our admissions office is fully operational in Rajapur mandal, Mahabubnagar. Parents can directly walk in with kids to receive counseling. Call us at +91 9133054131 to confirm timelines.
                </p>
              </div>
              <button 
                onClick={() => { setActiveTab("admission"); }}
                className="bg-indigo-600 hover:bg-slate-900 text-white font-semibold text-xs px-6 py-3 rounded-xl shadow-md transition-all flex items-center gap-2 flex-shrink-0"
              >
                Go to Admissions Desk <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </section>
        )}

        {/* NEW STUDENT ADMISSIONS PORTAL VIEW */}
        {activeTab === "admission" && (
          <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-100 text-xs font-bold uppercase tracking-wider">
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                Active Open Registrations
              </div>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-display text-slate-900">
                Student Admission Portal 2026-27
              </h1>
              <p className="text-sm text-slate-600 leading-relaxed">
                Apply online below to begin your admission journey. Once submitted, our AI Admissions Assistant can coach you instantly, and our real humans will call back within 24-48 business hours.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
              
              {/* Admission submission form Column */}
              <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-slate-100 shadow-xl shadow-slate-100/50">
                
                <div className="border-b border-slate-100 pb-4 mb-6">
                  <h3 className="text-lg font-bold font-display text-slate-900">Application Intake Desk</h3>
                  <p className="text-xs text-slate-500">Please provide verified phone numbers and parent details to coordinate. Fields marked with (*) are mandatory</p>
                </div>

                {submissionStatus === "success" && submittedAdmission ? (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="p-6 bg-emerald-50 rounded-2xl border border-emerald-100 text-slate-900 text-center space-y-6"
                  >
                    <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto text-xl font-bold">
                      ✓
                    </div>
                    <div>
                      <h4 className="text-xl font-bold font-display text-emerald-950">Application Logged Successfully!</h4>
                      <p className="text-xs text-slash-600 text-slate-600 mt-1">
                        Application Ref ID: <strong className="font-mono text-indigo-700 bg-white px-2 py-0.5 rounded border">{submittedAdmission.id}</strong>
                      </p>
                    </div>

                    <div className="bg-white p-4 rounded-xl text-left border border-emerald-100 my-4 space-y-2 text-xs">
                      <div><span className="text-slate-400">Student:</span> <strong className="text-slate-800">{submittedAdmission.studentName}</strong></div>
                      <div><span className="text-slate-400">Parent/Guardian:</span> <strong className="text-slate-800">{submittedAdmission.parentName}</strong></div>
                      <div><span className="text-slate-400">Applied Standard:</span> <strong className="text-slate-800">{submittedAdmission.grade}</strong></div>
                      <div><span className="text-slate-400">Call Mobile:</span> <strong className="text-slate-800">{submittedAdmission.phone}</strong></div>
                      <div><span className="text-slate-400">Registration Status:</span> <span className="bg-amber-100 text-amber-800 font-extrabold px-2.5 py-0.5 rounded text-[10px] uppercase tracking-wider">{submittedAdmission.status}</span></div>
                      <div className="pt-2 border-t border-emerald-100 text-[10px] text-amber-800 font-semibold leading-relaxed">
                        ⚠️ Under school regulations, every application must be reviewed and officially confirmed by the administrator before enrollment is finalized.
                      </div>
                    </div>

                    <p className="text-xs text-slate-500">
                      Our board officers has received the file. Would you like to consult our interactive <strong>AI Coach</strong> about the next documents checklist or interactive fee details?
                    </p>

                    <div className="flex flex-wrap gap-3 justify-center">
                      <button 
                        onClick={() => {
                          setSubmissionStatus("idle");
                          setSubmittedAdmission(null);
                        }}
                        className="px-4 py-2 rounded-xl text-xs bg-slate-900 text-white font-bold hover:bg-slate-800"
                      >
                        Submit Another Form
                      </button>
                      <button 
                        onClick={() => {
                          setAiChatOpen(true);
                          sendMessageToBackend(`I launched admission with ID ${submittedAdmission.id}. Explain the immediate documents checklist!`);
                        }}
                        className="px-4 py-2 rounded-xl text-xs bg-indigo-600 text-white font-bold hover:bg-indigo-700"
                      >
                        Consult AI Coach Instantly
                      </button>
                    </div>

                  </motion.div>
                ) : (
                  <form onSubmit={handleAdmissionSubmit} className="space-y-5">
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-700 block">Student's Full Name *</label>
                        <input 
                          type="text" 
                          required
                          placeholder="e.g. Rahul Reddy"
                          value={admissionForm.studentName}
                          onChange={(e) => setAdmissionForm({...admissionForm, studentName: e.target.value})}
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
                        />
                      </div>
                      
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-700 block">Parent / Guardian Full Name *</label>
                        <input 
                          type="text" 
                          required
                          placeholder="e.g. M. Srinivas Reddy"
                          value={admissionForm.parentName}
                          onChange={(e) => setAdmissionForm({...admissionForm, parentName: e.target.value})}
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-700 block">Target Standard / Grade *</label>
                        <select 
                          value={admissionForm.grade}
                          onChange={(e) => setAdmissionForm({...admissionForm, grade: e.target.value})}
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 text-xs bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
                        >
                          {ADMISSION_GRADES.map((g) => (
                            <option key={g} value={g}>{g}</option>
                          ))}
                        </select>
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-700 block">Contact Phone Number *</label>
                        <input 
                          type="tel" 
                          required
                          placeholder="10-digit mobile number"
                          value={admissionForm.phone}
                          onChange={(e) => setAdmissionForm({...admissionForm, phone: e.target.value})}
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-700 block">Parent Authorized Email Address</label>
                        <input 
                          type="email" 
                          placeholder="e.g. parent@gmail.com"
                          value={admissionForm.email}
                          onChange={(e) => setAdmissionForm({...admissionForm, email: e.target.value})}
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-700 block">Previous School Attended (If any)</label>
                        <input 
                          type="text" 
                          placeholder="School name and location"
                          value={admissionForm.previousSchool}
                          onChange={(e) => setAdmissionForm({...admissionForm, previousSchool: e.target.value})}
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-700 block">Parent Instructions or Student Interests (Optional)</label>
                      <textarea 
                        rows={3}
                        placeholder="Mention any specific interest in science labs, computer programs, volleyball, cricket coaching, or transport requirements..."
                        value={admissionForm.notes}
                        onChange={(e) => setAdmissionForm({...admissionForm, notes: e.target.value})}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all resize-none"
                      />
                    </div>

                    <div className="pt-2">
                      <button 
                        type="submit"
                        disabled={submissionStatus === "submitting"}
                        className="w-full py-4 bg-indigo-600 hover:bg-slate-900 text-white font-bold rounded-xl text-xs uppercase tracking-wider transition-colors shadow-lg shadow-indigo-100 disabled:bg-indigo-300"
                      >
                        {submissionStatus === "submitting" ? "Registering Information..." : "Submit Online Admission Application"}
                      </button>
                    </div>

                  </form>
                )}

              </div>

              {/* Admission FAQ and Live Tracking Desk */}
              <div className="lg:col-span-5 space-y-8">
                
                {/* APPLICATION TICKET TRACKER */}
                <div className="bg-slate-950 text-white p-6 rounded-3xl border border-slate-800 shadow-xl space-y-4">
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full bg-indigo-400 animate-pulse" />
                    <span className="text-[10px] font-bold tracking-widest text-indigo-400 uppercase">Interactive Check Progress</span>
                  </div>
                  <div>
                    <h3 className="text-base font-bold font-display">Track Your Application Status</h3>
                    <p className="text-[11px] text-slate-400 mt-0.5">Enter your submitted phone number to review counseling dates</p>
                  </div>

                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      placeholder="Enter registered mobile number"
                      value={trackingPhone}
                      onChange={(e) => setTrackingPhone(e.target.value)}
                      className="bg-slate-900 border border-slate-800 px-4 py-2.5 text-xs rounded-xl outline-none text-white w-full placeholder:text-slate-500"
                    />
                    <button 
                      onClick={handleTrackAdmission}
                      className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 rounded-xl text-xs font-bold text-white transition-colors"
                    >
                      Track
                    </button>
                  </div>

                  {trackingChecked && (
                    <div className="pt-2 space-y-3">
                      {trackedApplications.length > 0 ? (
                        trackedApplications.map((adm) => (
                          <div key={adm.id} className="bg-slate-900 p-3.5 rounded-xl border border-slate-800 text-xs space-y-2">
                            <div className="flex justify-between items-center bg-slate-950 px-2 py-1.5 rounded">
                              <span className="font-mono text-indigo-400 font-bold">{adm.id}</span>
                              <span className={`text-[9px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                                adm.status === "Confirmed"
                                  ? "bg-emerald-600 text-white font-extrabold"
                                  : adm.status === "Declined"
                                    ? "bg-rose-600 text-white font-extrabold"
                                    : adm.status === "Approved"
                                      ? "bg-emerald-500/20 text-emerald-400" 
                                      : "bg-amber-400/20 text-amber-300"
                              }`}>
                                {adm.status}
                              </span>
                            </div>
                            <div className="text-slate-300 grid grid-cols-2 gap-2 text-[11px]">
                              <div>Student: <strong>{adm.studentName}</strong></div>
                              <div>Standard: <strong>{adm.grade}</strong></div>
                            </div>
                            <p className="text-[10px] text-slate-400 border-t border-slate-800/80 pt-1.5 pb-1">
                              Registered: {new Date(adm.createdAt).toLocaleDateString()} at Mahabubnagar center.
                            </p>
                            {adm.status !== "Confirmed" && adm.status !== "Declined" && (
                              <p className="text-[10px] text-amber-300 font-semibold bg-amber-950/40 px-2 py-1.5 rounded border border-amber-900/40 leading-relaxed">
                                ⚠️ Every application must be approved and confirmed by the administrator before admission is finalized.
                              </p>
                            )}

                            {/* Direct Admin Quick Confirm Trigger */}
                            {adm.status !== "Confirmed" && adm.status !== "Declined" && (
                              <div className="pt-1 border-t border-slate-800/40">
                                <button
                                  onClick={() => {
                                    setIsAdminUnlocked(false);
                                    setAdminPinInput("");
                                    setAdminModeError("");
                                    const adminEl = document.getElementById("admin-controls-card-dock");
                                    if (adminEl) {
                                      adminEl.scrollIntoView({ behavior: "smooth" });
                                    }
                                  }}
                                  className="w-full text-center bg-rose-950/40 hover:bg-rose-900/40 border border-rose-900/30 text-rose-300 font-bold py-1 rounded text-[10px] tracking-wide transition-colors"
                                >
                                  ⚙ Admin: Confirm This Student's Admission
                                </button>
                              </div>
                            )}
                          </div>
                        ))
                      ) : (
                        <p className="text-xs text-rose-300 bg-rose-500/10 p-3 rounded-lg text-center font-semibold">
                          No registered application found for "{trackingPhone}". Double-check or try with "9133054131" (Demo data).
                        </p>
                      )}
                    </div>
                  )}
                </div>

                {/* ADMINISTRATIVE CONTROL DESK */}
                <div 
                  id="admin-controls-card-dock" 
                  className="bg-slate-900 border border-slate-800 text-white p-6 rounded-3xl shadow-xl space-y-4"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Lock className="w-3.5 h-3.5 text-rose-500" />
                      <span className="text-[10px] uppercase tracking-widest font-extrabold text-rose-400 font-mono">Administrative Control Desk</span>
                    </div>
                    <span className="text-[9px] bg-slate-950 px-2 py-0.5 rounded text-slate-400 font-mono">2026 Batch Intake</span>
                  </div>
                  <div>
                    <h3 className="text-sm font-bold font-display text-slate-100">Intake Board Manager</h3>
                    <p className="text-[11px] text-slate-400 mt-0.5">Authorize student admission registrations and dispatch instant SMS status certificates.</p>
                  </div>

                  {!isAdminUnlocked ? (
                    <div className="space-y-3 pt-1">
                      <p className="text-[11px] text-slate-400 font-medium">Please enter your system passcode to unlock the dashboard and confirm student registrations.</p>
                      <div className="flex gap-2">
                        <input 
                          type="password" 
                          placeholder="Enter Administrative PIN"
                          value={adminPinInput}
                          onChange={(e) => setAdminPinInput(e.target.value)}
                          className="bg-slate-950 border border-slate-800 px-3 py-2 text-xs rounded-xl outline-none text-white w-full placeholder:text-slate-600 font-mono"
                          onKeyDown={(e) => {
                            if (e.key === "Enter") handleAdminAuthentication();
                          }}
                        />
                        <button 
                          onClick={handleAdminAuthentication}
                          className="px-4 py-2 bg-rose-600 hover:bg-rose-500 rounded-xl text-xs font-bold text-white transition-colors"
                        >
                          Unlock
                        </button>
                      </div>
                      {adminModeError && (
                        <p className="text-[10px] text-rose-400 font-semibold">{adminModeError}</p>
                      )}
                    </div>
                  ) : (
                    <div className="space-y-4 pt-1">
                      <div className="flex justify-between items-center bg-slate-950 p-2 rounded-xl text-xs">
                        <span className="text-rose-400 font-bold font-mono">⚠️ Admin Mode Unlocked</span>
                        <button 
                          onClick={() => {
                            setIsAdminUnlocked(false);
                            setAdminPinInput("");
                          }}
                          className="text-[10px] text-slate-400 hover:text-white underline font-semibold"
                        >
                          Lock Session
                        </button>
                      </div>

                      {/* Administrative Navlinks / Sub-Tabs */}
                      <div className="grid grid-cols-3 gap-1 p-1 bg-slate-950 rounded-xl border border-slate-800">
                        <button
                          type="button"
                          onClick={() => setAdminSubTab("pending")}
                          className={`py-1.5 px-1 rounded-lg text-[9px] sm:text-[10px] font-bold transition-all text-center flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-1.5 ${
                            adminSubTab === "pending"
                              ? "bg-slate-800 text-white shadow-md border border-slate-700/50"
                              : "text-slate-400 hover:text-white hover:bg-slate-900/40"
                          }`}
                        >
                          <ListTodo className="w-3 h-3 text-amber-400 shrink-0" />
                          <span>Pending ({allAdmissionsList.filter(a => a.status !== "Confirmed" && a.status !== "Declined").length})</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setAdminSubTab("confirmed")}
                          className={`py-1.5 px-1 rounded-lg text-[9px] sm:text-[10px] font-bold transition-all text-center flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-1.5 ${
                            adminSubTab === "confirmed"
                              ? "bg-slate-800 text-emerald-400 shadow-md border border-slate-700/50"
                              : "text-slate-400 hover:text-emerald-400 hover:bg-slate-900/40"
                          }`}
                        >
                          <CheckCircle className="w-3 h-3 text-emerald-400 shrink-0" />
                          <span>Confirmed ({allAdmissionsList.filter(a => a.status === "Confirmed").length})</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setAdminSubTab("declined")}
                          className={`py-1.5 px-1 rounded-lg text-[9px] sm:text-[10px] font-bold transition-all text-center flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-1.5 ${
                            adminSubTab === "declined"
                              ? "bg-slate-800 text-rose-400 shadow-md border border-slate-700/50"
                              : "text-slate-400 hover:text-rose-400 hover:bg-slate-900/40"
                          }`}
                        >
                          <XCircle className="w-3 h-3 text-rose-400 shrink-0" />
                          <span>Declined ({allAdmissionsList.filter(a => a.status === "Declined").length})</span>
                        </button>
                      </div>

                      <div className="space-y-3 max-h-[250px] overflow-y-auto pr-1">
                        {(() => {
                          const filteredList = allAdmissionsList.filter((adm) => {
                            if (adminSubTab === "pending") return adm.status !== "Confirmed" && adm.status !== "Declined";
                            if (adminSubTab === "confirmed") return adm.status === "Confirmed";
                            if (adminSubTab === "declined") return adm.status === "Declined";
                            return true;
                          });

                          if (filteredList.length > 0) {
                            return filteredList.map((adm) => (
                              <div key={adm.id} className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2 hover:border-slate-700 transition-all">
                                <div className="flex justify-between items-center text-xs">
                                  <span className="font-mono text-indigo-400 font-black">{adm.id}</span>
                                  <span className={`text-[9px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                                    adm.status === "Confirmed" 
                                      ? "bg-emerald-600 text-white font-extrabold" 
                                      : adm.status === "Declined"
                                        ? "bg-rose-600 text-white font-extrabold"
                                        : adm.status === "Approved"
                                          ? "bg-teal-500/20 text-teal-400"
                                          : "bg-amber-400/20 text-amber-300"
                                  }`}>
                                    {adm.status}
                                  </span>
                                </div>
                                
                                <div className="text-[11px] text-slate-300 grid grid-cols-2 gap-x-2 gap-y-1">
                                  <div>Student: <strong className="text-white">{adm.studentName}</strong></div>
                                  <div>Grade: <strong>{adm.grade}</strong></div>
                                  <div>Parent: <strong>{adm.parentName}</strong></div>
                                  <div>Phone: <strong>{adm.phone}</strong></div>
                                </div>

                                {adm.status !== "Confirmed" && adm.status !== "Declined" ? (
                                  <div className="flex flex-col sm:flex-row gap-2 pt-1">
                                    <button
                                      type="button"
                                      onClick={() => handleConfirmAdmission(adm.id)}
                                      disabled={adminActionStatus.id === adm.id && adminActionStatus.status === "submitting"}
                                      className="flex-1 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 py-2 rounded-lg text-[10px] sm:text-[11px] font-black tracking-wider uppercase transition-colors shadow-md flex items-center justify-center gap-1"
                                    >
                                      {adminActionStatus.id === adm.id && adminActionStatus.status === "submitting" ? (
                                        <span>Processing...</span>
                                      ) : (
                                        <>
                                          <CheckSquare className="w-3.5 h-3.5 text-white" />
                                          <span>Confirm Admission</span>
                                        </>
                                      )}
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => handleDeclineAdmission(adm.id)}
                                      disabled={adminActionStatus.id === adm.id && adminActionStatus.status === "submitting"}
                                      className="flex-1 bg-rose-600 hover:bg-rose-500 disabled:bg-slate-800 py-2 rounded-lg text-[10px] sm:text-[11px] font-black tracking-wider uppercase transition-colors shadow-md flex items-center justify-center gap-1 text-white"
                                    >
                                      {adminActionStatus.id === adm.id && adminActionStatus.status === "submitting" ? (
                                        <span>Processing...</span>
                                      ) : (
                                        <>
                                          <XCircle className="w-3.5 h-3.5 text-white" />
                                          <span>Don't Confirm</span>
                                        </>
                                      )}
                                    </button>
                                  </div>
                                ) : adm.status === "Confirmed" ? (
                                  <div className="bg-emerald-900/30 text-emerald-400 text-center py-2 rounded-lg border border-emerald-900/40 text-[10px] font-bold flex items-center justify-center gap-1.5">
                                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                                    <span>Officially Confirmed & SMS Sent</span>
                                  </div>
                                ) : (
                                  <div className="bg-rose-950/25 text-rose-400 text-center py-2 rounded-lg border border-rose-900/30 text-[10px] font-bold flex items-center justify-center gap-1.5">
                                    <XCircle className="w-3.5 h-3.5 text-rose-400" />
                                    <span>Admission Declined & Parent Notified</span>
                                  </div>
                                )}
                                
                                {adminActionStatus.id === adm.id && adminActionStatus.status === "error" && (
                                  <p className="text-[10px] text-rose-400 font-bold mt-1 text-center bg-rose-950/20 p-1.5 rounded">{adminActionStatus.error}</p>
                                )}
                              </div>
                            ));
                          } else {
                            return (
                              <div className="text-center py-8 px-4 bg-slate-950/30 border border-slate-900/80 rounded-xl">
                                <p className="text-[11px] text-slate-500 font-bold tracking-wide">
                                  {adminSubTab === "pending" ? "🎉 No pending applications to review!" : 
                                   adminSubTab === "confirmed" ? "No student records in Confirmed List yet." : 
                                   "No student records in Declined List."}
                                </p>
                              </div>
                            );
                          }
                        })()}
                      </div>
                    </div>
                  )}
                </div>

                {/* DISPATCHED SMS NOTIFICATION LOG */}
                <div className="bg-slate-900 border border-slate-800 text-white p-6 rounded-3xl shadow-xl space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                      <span className="text-[10px] font-bold tracking-widest text-emerald-400 uppercase">Real-Time SMS Sentinel</span>
                    </div>
                    <span className="bg-emerald-950 text-emerald-300 text-[9px] px-2.5 py-1 rounded font-mono font-bold">
                      Admin Call Receiver: 7670968526
                    </span>
                  </div>
                  <div>
                    <h3 className="text-sm font-bold font-display text-slate-100">Intake Dispatch Outbox</h3>
                    <p className="text-[11px] text-slate-400 mt-0.5">Instant alerts dispatched to administrative receiver line upon submission.</p>
                  </div>

                  <div className="space-y-3 max-h-[220px] overflow-y-auto pr-1 text-xs">
                    {dispatchedSmsList.length > 0 ? (
                      dispatchedSmsList.map((sms, index) => (
                        <div key={index} className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5 hover:border-emerald-500/30 transition-all">
                          <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono">
                            <span className="text-emerald-400 font-bold">✓ DISPATCHED</span>
                            <span>{new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
                          </div>
                          <p className="text-[11px] text-slate-300 leading-normal font-mono bg-slate-900/60 p-2 rounded border border-slate-800/60 font-sans">
                            {sms.message}
                          </p>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-6 text-slate-500 text-xs">
                        <p className="font-semibold">No messages in outbox yet.</p>
                        <p className="text-[10px] text-slate-600 mt-1">Submit an admission form on the left to dispatch instant SMS notifications to +91 7670968526 live!</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* ADMISSION FAQS */}
                <div className="bg-slate-50 p-6 rounded-3xl border border-slate-200/60 space-y-4">
                  <h3 className="text-lg font-bold font-display text-slate-950">Intake Desk FAQs</h3>
                  
                  <div className="space-y-4">
                    {ADMISSION_FAQ.map((faq, idx) => (
                      <div key={idx} className="space-y-1.5">
                        <span className="text-xs font-bold text-indigo-900 block font-display leading-snug">
                          Q: {faq.q}
                        </span>
                        <p className="text-xs text-slate-600 leading-relaxed font-sans pl-3 border-l border-indigo-200">
                          {faq.a}
                        </p>
                      </div>
                    ))}
                  </div>

                  <div className="p-4 bg-indigo-50 rounded-xl border border-indigo-100 flex items-center justify-between">
                    <div>
                      <span className="text-xs font-bold block text-slate-900">Direct Office Call</span>
                      <a href="tel:9133054131" className="text-xs font-extrabold text-indigo-600">9133054131</a>
                    </div>
                    <span className="text-[10px] uppercase font-bold text-slate-400 font-mono">ESTD 2006</span>
                  </div>
                </div>

              </div>

            </div>
          </section>
        )}

      </main>

      {/* COMPREHENSIVE COMPACT REUSABLE CONTACT AND ROUTING MAP FOOTER */}
      <footer className="bg-slate-900 text-white border-t border-slate-800 pt-16 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-12 gap-12 border-b border-slate-800 pb-12 mb-8">
          
          {/* Logo & Legacy Desk */}
          <div className="md:col-span-4 space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-black">SPV</div>
              <span className="text-lg font-bold font-display text-slate-100">Sri Prathibha Vidhyanikentan</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed font-sans">
              Founded in 2006, Sri Prathibha Vidhyanikentan School is an elite center of learning dedicated to cultivating state boardSSC board rankers through integrated technology smart boards, full-capacity physical science labs, and comprehensive physical sports curriculum.
            </p>
            <div className="flex items-center gap-1">
              <span className="px-2.5 py-1 rounded bg-slate-800 text-emerald-400 font-mono text-[10px] font-bold">20+ YEARS TRUST</span>
              <span className="px-2.5 py-1 rounded bg-slate-800 text-indigo-400 font-mono text-[10px] font-bold">DIGITAL CAMPUS</span>
            </div>
          </div>

          {/* Quick links */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-widest text-slate-300">Quick Navigation</h4>
            <div className="grid grid-cols-1 gap-2 text-xs">
              {[
                { label: "Home Showcase", value: "home" },
                { label: "Honors & Achievements", value: "achievements" },
                { label: "High-end Facilities", value: "facilities" },
                { label: "Campus Milestones Life", value: "gallery" },
                { label: "Register New Admission", value: "admission" }
              ].map((link, idx) => (
                <button 
                  key={idx}
                  onClick={() => {
                    setActiveTab(link.value as any);
                    window.scrollTo({ top: 0, behavior: "smooth" });
                  }}
                  className="text-left text-slate-400 hover:text-indigo-400 hover:underline transition-all block"
                >
                  {link.label}
                </button>
              ))}
            </div>
          </div>

          {/* Contact Details & Official Map Address */}
          <div className="md:col-span-5 space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-widest text-slate-300">Direct Campus Address Desk</h4>
            
            <div className="space-y-2 text-xs text-slate-450 text-slate-300 font-sans">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-rose-500 flex-shrink-0 mt-0.5" />
                <span>
                  <strong>Campus Landmark:</strong> Rajapur mandal, Mahabubnagar district, Telangana, Pin: 509202, India.
                </span>
              </div>

              <div className="flex items-start gap-2">
                <Phone className="w-4 h-4 text-emerald-500 flex-shrink-0 mt-0.5" />
                <div>
                  <span className="block text-slate-400">Admissions Desk Direct Call:</span>
                  <a href="tel:9133054131" className="text-base font-bold font-mono text-indigo-400 block hover:underline">
                    +91 9133054131
                  </a>
                  <span className="block text-[10px] text-slate-500">Timing: Monday to Saturday, 9:00 AM - 4:30 PM</span>
                </div>
              </div>
            </div>

            <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-800 text-slate-400 text-xs">
              <span className="block font-bold text-slate-200 mb-1">State SSC Board Affiliation</span>
              <p className="text-[11px] leading-snug">
                Recognized by the Government of Telangana state education board. Catering to standards Primary, Middle School, and Secondary SSP exam levels since 20 years.
              </p>
            </div>
          </div>

        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-slate-500">
          <span>&copy; {new Date().getFullYear()} Sri Prathibha Vidhyanikentan School. All rights reserved.</span>
          <span className="flex items-center gap-1.5 bg-slate-950 px-3 py-1.5 rounded text-[10px] text-slate-400">
            <Check className="w-3.5 h-3.5 text-indigo-500" />
            AI Admission Assistant Powered
          </span>
        </div>
      </footer>


      {/* FLOATING CHAT ASSISTANT WIDGET (AI TUTOR & ADMISSION COACH) */}
      <div className="fixed bottom-6 right-6 z-50">
        
        {/* Toggle Button */}
        <button
          onClick={() => setAiChatOpen(!aiChatOpen)}
          id="floating-ai-tutor-bubble"
          className="w-14 h-14 rounded-full bg-gradient-to-tr from-indigo-600 via-indigo-700 to-rose-600 text-white flex items-center justify-center shadow-2xl hover:scale-105 active:scale-95 transition-all relative group"
        >
          {aiChatOpen ? (
            <X className="w-6 h-6" />
          ) : (
            <React.Fragment>
              <MessageSquare className="w-6 h-6" />
              <span className="absolute top-[-2px] right-[-2px] w-4 h-4 bg-rose-500 rounded-full border-2 border-white flex items-center justify-center text-[8px] font-extrabold text-white animate-pulse">
                AI
              </span>
            </React.Fragment>
          )}
          {/* Tooltip */}
          <span className="absolute right-16 bg-slate-900 text-white text-[10px] font-bold px-3 py-1.5 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow pointer-events-none">
            Sri Prathibha AI Admission Desk
          </span>
        </button>

        {/* Chat Drawer */}
        <AnimatePresence>
          {aiChatOpen && (
            <motion.div
              initial={{ opacity: 0, y: 30, scale: 0.92 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 30, scale: 0.92 }}
              className="absolute bottom-16 right-0 w-[90vw] sm:w-[400px] h-[550px] bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col"
              id="ai-tutor-chat-panel"
            >
              
              {/* Header */}
              <div className="bg-gradient-to-r from-indigo-950 via-indigo-900 to-indigo-950 text-white p-4 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-indigo-500 to-rose-500 flex items-center justify-center text-white text-xs font-black ring-2 ring-white/10">
                    AI
                  </div>
                  <div>
                    <span className="block font-bold text-sm font-display tracking-wide">
                      Helper Tutor Coach
                    </span>
                    <span className="block text-[10px] text-indigo-300">
                      Sri Prathibha Vidhyanikentan Admission Desk
                    </span>
                  </div>
                </div>
                <button 
                  onClick={() => setAiChatOpen(false)}
                  className="p-1 rounded bg-slate-800 text-slate-450 text-slate-300 hover:bg-slate-700 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* API Token Key Disclaimer inside chat block (No Custom UI for Keys, purely inline documentation warning) */}
              <div className="bg-amber-50 border-b border-amber-100 px-4 py-2 flex items-center gap-2 text-amber-900 text-[10px]">
                <HelpCircle className="w-3.5 h-3.5 text-amber-600 flex-shrink-0" />
                <span>
                  Querying the modern Gemini SDK. Make sure your environment secret keys are active.
                </span>
              </div>

              {/* Messages Body */}
              <div className="flex-grow overflow-y-auto p-4 space-y-4 bg-slate-50/50">
                {aiMessages.map((msg, i) => (
                  <div 
                    key={i} 
                    className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                  >
                    <div className={`max-w-[85%] p-3.5 rounded-2xl text-xs leading-relaxed shadow-sm ${
                      msg.role === "user" 
                        ? "bg-indigo-600 text-white rounded-tr-none" 
                        : "bg-white text-slate-800 rounded-tl-none border border-slate-100"
                    }`}>
                      <div className="font-sans whitespace-pre-wrap">
                        {msg.content}
                      </div>
                      <span className={`block text-[8px] mt-1.5 text-right font-mono ${
                        msg.role === "user" ? "text-indigo-200" : "text-slate-400"
                      }`}>
                        {msg.timestamp}
                      </span>
                    </div>
                  </div>
                ))}

                {isAiTyping && (
                  <div className="flex justify-start">
                    <div className="bg-white border p-3 rounded-2xl rounded-tl-none flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-600 animate-bounce" style={{ animationDelay: "0ms" }} />
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-600 animate-bounce" style={{ animationDelay: "150ms" }} />
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-600 animate-bounce" style={{ animationDelay: "300ms" }} />
                    </div>
                  </div>
                )}
                <div ref={chatBottomRef} />
              </div>

              {/* Fast interactive prompts selection box */}
              <div className="px-4 py-2 border-t border-slate-100 bg-white flex gap-1.5 overflow-x-auto whitespace-nowrap scrollbar-none">
                {[
                  { label: "Steps to Register?", query: "How do I take new student admissions in Sri Prathibha Vidhyanikentan?" },
                  { label: "Our Smart Boards", query: "Can you explain details about the digital boards and interactive classroom technologies?" },
                  { label: "Contact Phone Office", query: "What is the phone number and campus location again?" },
                  { label: "SSC Track Record", query: "Can you list your latest GPA toppers track record?" }
                ].map((item, idx) => (
                  <button
                    key={idx}
                    onClick={() => triggerAiTutorMessage(item.query)}
                    className="bg-slate-100 hover:bg-indigo-50 border hover:border-indigo-100 text-slate-700 hover:text-indigo-700 rounded-full px-3 py-1.5 text-[10px] font-bold transition-all"
                  >
                    {item.label}
                  </button>
                ))}
              </div>

              {/* Input Form */}
              <form onSubmit={handleSendAiMessage} className="p-3 bg-white border-t border-slate-100 flex gap-2">
                <input 
                  type="text" 
                  value={userMsgInput}
                  onChange={(e) => setUserMsgInput(e.target.value)}
                  placeholder="Ask Coach about admission process or school specialties..."
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-indigo-500 placeholder:text-slate-400 font-sans"
                />
                <button 
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-700 text-white p-2.5 rounded-xl transition-colors flex items-center justify-center flex-shrink-0 shadow-md shadow-indigo-100"
                >
                  <SendHorizontal className="w-4 h-4" />
                </button>
              </form>

            </motion.div>
          )}
        </AnimatePresence>

      </div>

    </div>
  );
}

// Workaround subcomponent to render Lucide CPU icon reliably
function CpuWorkaroundIcon() {
  return (
    <svg className="w-4 h-4 stroke-current" viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="4" y="4" width="16" height="16" rx="2" />
      <rect x="9" y="9" width="6" height="6" />
      <path d="M9 1v3" />
      <path d="M15 1v3" />
      <path d="M9 20v3" />
      <path d="M15 20v3" />
      <path d="M20 9h3" />
      <path d="M20 15h3" />
      <path d="M1 9h3" />
      <path d="M1 15h3" />
    </svg>
  );
}
