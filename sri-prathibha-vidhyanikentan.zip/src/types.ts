export interface Admission {
  id: string;
  studentName: string;
  parentName: string;
  grade: string;
  phone: string;
  email: string;
  previousSchool?: string;
  notes?: string;
  status: "Pending" | "Reviewed" | "Approved" | "Contacted" | "Confirmed" | "Declined";
  createdAt: string;
}

export interface Achievement {
  id: string;
  title: string;
  metric: string;
  description: string;
  category: "Academic" | "Sports" | "Extracurricular";
  year: string;
}

export interface Facility {
  id: string;
  name: string;
  description: string;
  featureTitle: string;
  features: string[];
  specs: string[];
}

export interface GalleryItem {
  id: string;
  title: string;
  category: "Campus" | "Labs" | "Sports" | "Celebrations";
  description: string;
  imageAlt: string;
  iconName: string;
}

export interface Message {
  role: "user" | "assistant";
  content: string;
  timestamp: string;
}
